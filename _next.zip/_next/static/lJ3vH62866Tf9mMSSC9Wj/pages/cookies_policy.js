(window.webpackJsonp = window.webpackJsonp || []).push([
	["1610"], {
		TPFy: function(e, t, o) {
			"use strict";
			o.r(t);
			var n = o("q1tI"),
				a = o.n(n),
				l = o("yWC8"),
				c = o("wTIg"),
				r = o("AuK3"),
				i = Object(c.a)("h1", {
					target: "egpkm6r0"
				})("font-weight:bold;font-size:64px;letter-spacing:1px;color:", r.a.colors.black, ";"),
				p = Object(c.a)("h2", {
					target: "egpkm6r1"
				})("font-weight:bold;font-size:18px;letter-spacing:1px;color:", r.a.colors.black, ";"),
				u = Object(c.a)("p", {
					target: "egpkm6r2"
				})("font-size:12px;line-height:30px;letter-spacing:1px;color:", r.a.colors.black, ";");
			t.default = function() {
				return a.a.createElement(l.a, null, a.a.createElement(l.c, null, a.a.createElement(i, null, "Cookie Policy"), a.a.createElement(p, null, "About this Cookie Policy"), a.a.createElement(u, null, "foobar")))
			}
		},
		xzhp: function(e, t, o) {
			(window.__NEXT_P = window.__NEXT_P || []).push(["/cookies_policy", function() {
				var e = o("TPFy");
				return {
					page: e.default || e
				}
			}])
		}
	},
	[
		["xzhp", "5d41", "9da1"]
	]
]);